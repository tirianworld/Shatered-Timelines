# CFXR prefab assets for a web app

Converted from the Unity `CFXR Prefabs` and `CFXR Assets` resources.

- `manifest.json`: all effect definitions in one file.
- `effects/<category>/*.json`: individual effect definitions.
- `textures/*.png`: original PNG textures linked by the definitions.
- `style-cartoon.json`: visual direction for a cartoon renderer.
- `AI-STUDIO-PROMPT.md`: prompt to use the assets in AI Studio.

The definitions include emitter settings, timing, shapes, sizes, velocities, colors, bursts, sprite-sheet settings, and texture paths. These are web-oriented data, not Unity `.prefab` files or pre-rendered animation frames; an app will need a renderer to animate them.